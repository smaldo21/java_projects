import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.PrintWriter;

public class GradeCalculator 
{
	public static void main(String[] args) throws IOException
	{
		String courseName = "";
		int numCategories = 0;
		
		String cat1 = "", cat2 = "", cat3 = "";
		int weight1 = 0, weight2 = 0, weight3 = 0;
		
		boolean defaultUsed = false;
		
		System.out.println("========================================");
		System.out.println("CMSC203 Project 1 - Grade Calculator");
		System.out.println("========================================");
		
		System.out.print("Loading configuration from gradeconfig.txt");
		
		File configFile = new File("gradeconfig.txt");
		
		if(configFile.exists())
		{
			Scanner config = new Scanner(configFile);
			courseName = config.nextLine();
			numCategories = config.nextInt();
			
			int totalWeight = 0;
			
			for(int i = 1; i <= numCategories; i++)
			{
				String name = config.next();
				int weight = config.nextInt();
				
				totalWeight += weight;
				
				if(i == 1)
				{
					cat1 = name;
					weight = weight;
				}
				else if(i == 2)
				{
					cat2 = name;
					weight2 = weight;
				}
				else if(i==3)
				{
					cat3 = name;
					weight3 = weight;
				}
			}
			if(totalWeight != 100)
			{
				defaultUsed = true;
			}
			config.close();
		}
		else
		{
			defaultUsed = true;
		}
		
		//use boolean result to determine if if-statement is used
		if(defaultUsed)
		{
			System.out.println("Invalid or missing config file.");
			System.out.println("Using default configuration.\n");
			
			courseName = "CMSC203 Computer Science";
			numCategories = 3;
			
			cat1 = "Projects";
			weight1 = 40;
			
			cat2 = "Quizzes";
			weight2 = 30;
			
			cat3 = "Exams";
			weight3 = 30;
			
		}
		else
		{
			System.out.println("Configuration loaded successfully.\n");
		}
		
		System.out.println("Using input file: grades_input.txt");
		System.out.println("Using output file: grades_report.txt\n");
		
		File inputFile = new File("grades_input.txt");
		
		if(!inputFile.exists())
		{
			System.out.println("Error: grades_input.txt not found");
			System.out.println("Program exiting.");
		}
		
		Scanner input = new Scanner(inputFile);
		System.out.println("Reading student scores...\n");
		
		String firstName = input.nextLine();
		String lastName = input.nextLine();
		
		double avg1 = 0, avg2 = 0, avg3 = 0;
		
		for(int i = 1; i <= numCategories; i++)
		{
			if(!input.hasNextLine())
			{
				break;
			}
			
			String categoryName = input.nextLine();
			
			if(!input.hasNextInt())
			{
				break;
			}
			
			int numScores = input.nextInt();
			
			double total = 0;
			
			int count = 0;
			
			while(count < numScores && input.hasNextDouble())
			{
				total += input.nextDouble();
				count++;
			}
			
			
			if(input.hasNextLine())
			{
				input.nextLine();
			}
			
			double average = 0;
			
			if(numScores > 0)
			{
				average = total/numScores;
			}
			if(categoryName.equals(cat1))
			{
				avg1 = average;
			}
			else if (categoryName.equals(cat2))
			{
				avg2 = average;
			}
			else if(categoryName.equals(cat3))
			{
				avg3 = average;
			}
			else
			{
				System.out.println("Category not found: " + categoryName);
			}
		}
		
		input.close();
		
		double overall = (avg1 * weight1/100.0) + (avg2 * weight2/100.0) + (avg3 * weight3/100.0);
		
		String baseLetter;
		
		if(overall >= 90)
		{
			baseLetter = "A";
		}
		else if(overall >= 80)
		{
			baseLetter = "B";
		}
		else if(overall >= 70)
		{
			baseLetter = "C";
		}
		else if(overall >= 60)
		{
			baseLetter = "D";
		}
		else
		{
			baseLetter = "F";
		}
		
		//Keyboard input validation loop
		Scanner keyboard = new Scanner(System.in);
		String choice;
		
		do
		{
			System.out.println("Apply  +/= grading? (Y/N): ");
			choice = keyboard.nextLine();
		}
		while(!choice.equalsIgnoreCase("Y") && !choice.equalsIgnoreCase("N"));
		
		
		String finalLetter = baseLetter;
		
		if(choice.equalsIgnoreCase("Y") && !baseLetter.equals("F"))
		{
			double decimal = overall%10;
			
			if(decimal >= 8)
			{
				finalLetter = baseLetter + "+";
			}
			else if(decimal <= 2)
			{
				finalLetter = baseLetter + "-";
			}
			
		}
		
		
		//output
		System.out.println("\nStudent " + firstName + " " + lastName);
		System.out.println("Course: " + courseName);
		
		System.out.println("\nCategoryResults:");
		System.out.printf("%s (%d%%): average = %.2f\n", cat1, weight1, avg1);
		System.out.printf("%s (%d%%): average = %.2f\n", cat2, weight2, avg2);
		System.out.printf("%s (%d%%): average = %.2f\n", cat3, weight3, avg3);
		System.out.printf("\nOverall numeric avg: %.2f\n", overall);
		System.out.printf("Base letter grade: %s\n" + baseLetter);
        System.out.printf("Final letter grade: %s\n" + finalLetter);		
		
        if (defaultUsed)
        {
            System.out.println("\nDefault configuration was used.");
        }
        
        //Write to file
        PrintWriter output = new PrintWriter(new FileWriter("grades_report.txt"));
        
        output.println("Student: " + firstName + " " + lastName);
        output.println("Course: " + courseName);
        output.println();

        output.printf("%s (%d%%): %.2f\n", cat1, weight1, avg1);
        output.printf("%s (%d%%): %.2f\n", cat2, weight2, avg2);
        output.printf("%s (%d%%): %.2f\n", cat3, weight3, avg3);

        output.printf("\nOverall Average: %.2f\n", overall);
        output.println("Final Letter Grade: " + finalLetter);

        if(defaultUsed)
        {
        	output.println("Default configuration was used");
        }
        output.close();
        
        System.out.println("\nSummary written to grades_report.txt");
        
	}
	
}

	